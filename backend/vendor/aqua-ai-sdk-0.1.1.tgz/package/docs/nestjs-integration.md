# Aqua AI TypeScript / NestJS SDK 接入指南

官方 SDK 的 npm 包名为 `@aqua-ai/sdk`。核心客户端不依赖 NestJS，NestJS 适配从 `@aqua-ai/sdk/nestjs` 导入。

## 接入准备

平台方需创建并启用租户、给租户授权所需 `agent:*` 与 `stateless:*` 工作流，再通过安全渠道下发测试/生产环境各自的 base URL 和 service key。service key 只能保存在后端 Secret Manager 或服务端环境变量中。

SDK 默认请求超时为 300 秒；只有明确需要更短或更长的调用才应通过客户端或单次请求的 `timeoutMs` 覆盖，无需额外提供超时环境变量。

推荐环境变量：

```text
AQUA_AI_BASE_URL=https://aquai.example.com
AQUA_AI_SERVICE_KEY=<tenant-service-key>
```

`AQUA_AI_WORKFLOW_ID`、`AQUA_AI_WORKFLOW_VERSION` 和 `AQUA_AI_TIMEOUT_MS` 都不是 SDK 必需配置。工作流 ID 是每次 `workflows.run()` 的调用参数；工作流版本省略时由 Aqua AI 服务端选择该工作流的当前激活版本；默认请求超时已经是 300 秒。

NestJS 使用 `AquaAIModule.forRootAsync` 从 `ConfigService` 装配，业务 service 通过 `@Inject(AQUA_AI_CLIENT)` 获得单例客户端。

```ts
import { Module } from "@nestjs/common";
import { AquaAIModule } from "@aqua-ai/sdk/nestjs";

@Module({
  imports: [
    AquaAIModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        baseUrl: config.getOrThrow("AQUA_AI_BASE_URL"),
        auth: {
          type: "serviceKey",
          serviceKey: config.getOrThrow("AQUA_AI_SERVICE_KEY"),
        },
      }),
    }),
  ],
})
export class AppModule {}
```

## 身份选择

- 后端代用户聊天、租户无状态工作流、代用户充值/扣减/账单：service-key client。
- 用户本人会话历史、本人余额/流水：Bearer client，token 或 tokenProvider 由业务认证系统提供。
- SDK 不接收 JWT signing secret，不签发 token，也不会在鉴权失败后尝试其他凭据。

外部用户 ID 在 service-key 方法中保持业务侧原值，Aqua AI 服务端负责租户命名空间。Bearer 会话接口的路径 user ID 需使用服务端识别的完整 ID（如 `tenant-id:subject`）。

### 租户 JWT 密钥不属于 SDK 配置

租户 `jwt_secret` 只在业务方需要自行签发终端用户 Bearer JWT 时使用，例如让小程序或 App 以用户身份直接访问本人会话、余额和流水。该密钥应由业务方自己的认证服务保存在 Secret Manager 或服务端环境变量中，用于生成 JWT；生成后的 token 再通过 SDK 的 `token` 或 `tokenProvider` 传入。

不要把 `jwt_secret` 传给 `AquaAIClient`，也不要将它下发到浏览器、小程序或 App。仅使用 service-key client 调用工作流、代用户聊天或账务接口时，对方无需配置租户 `jwt_secret`。

## 调用一个或多个工作流

SDK 不设置全局工作流 ID。每次调用显式传入 `workflowId`，同一个客户端可以调用租户已授权的多个工作流：

```ts
await aqua.workflows.run("daily-insight", {
  idempotencyKey: "daily:user-42:2026-08-13",
  runReference: "task:daily:user-42:2026-08-13",
  input: dailyInsightInput,
});

await aqua.workflows.run("weekly-summary", {
  idempotencyKey: "weekly:user-42:2026-W33",
  runReference: "task:weekly:user-42:2026-W33",
  input: weeklySummaryInput,
});
```

默认不传 `workflowVersion`，由服务端发布和切换当前激活版本。只有确实需要复现某个历史版本时，才在单次请求中显式传入：

```ts
await aqua.workflows.run("daily-insight", {
  workflowVersion: "daily-insight/1.0.0",
  idempotencyKey,
  runReference,
  input,
});
```

## 流式对话

`chat.stream` 返回带 `conversationId` 的 `AsyncIterable`。业务方可处理 token、step/stage 进度、ping、error 和 done；新增的未知事件会以 `unknown` 返回。`chat.complete` 适合只需要最终文本的后端接口，以 done 的 `full_response` 为最终结果，流内 error 或无 done 断流会抛错。

```ts
const result = await aqua.chat.complete({
  userId: "external-user-42",
  message: "生成今日建议",
});

console.log(result.conversationId, result.response);
```

不要自动重放聊天或工作流请求。网络失败后是否再次执行必须由业务流程结合 request ID、账务状态和幂等设计决定。

## 错误处理

- `AquaAIHttpError`：读取 `status`、`code`、`requestId`、`retryable`、`details`。
- `AquaAITimeoutError` / `AquaAIAbortError` / `AquaAINetworkError`：分别处理超时、主动取消和网络错误。
- `AquaAIProtocolError` / `AquaAIStreamError`：协议或已建立 SSE 流内错误。
- 402 表示余额不足，401 表示凭据无效/过期，403 表示租户未授权，429 表示限流。

日志只记录错误 kind/status/code/requestId；严禁记录 client options、Authorization、X-API-Key 或完整请求体。

## 密钥轮换和环境隔离

每个环境使用独立租户凭据。service key 轮换会使旧 key 立即失效，应先在 Secret Manager 更新，再滚动重启全部实例并验证 401 消失。怀疑泄漏时立即在 Aqua AI 管理端轮换，不要等待正常发布窗口。

## 联调与上线

1. 从交付方获取 `aqua-ai-sdk-0.1.1.tgz`，执行 `npm install ./aqua-ai-sdk-0.1.1.tgz`。
2. 配置测试环境的 `AQUA_AI_BASE_URL` 和通过独立安全渠道获取的 `AQUA_AI_SERVICE_KEY`。
3. 验证工作流和流式聊天，并核对 Aqua AI dashboard 中的租户归因、工作流权限和积分流水。
4. 生产切换后监控 401/402/403/429/5xx 和 request ID，不采集密钥。

## 包内文件

npm tarball 只包含编译后的 `dist/`、类型声明、`README.md`、`docs/`、`LICENSE` 和 `package.json`，不包含 SDK TypeScript 源码、测试、构建脚本、依赖目录或 Aqua AI 服务端源码。
