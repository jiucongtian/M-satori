# @aqua-ai/sdk

Aqua AI 官方服务端 TypeScript SDK。支持 Node.js 20+，提供 ESM、CommonJS、完整类型声明和可选 NestJS 动态模块。

完整第三方接入说明见 [`docs/nestjs-integration.md`](docs/nestjs-integration.md)。

> 仅用于可信后端。不得把租户 service key 放入浏览器、小程序、App bundle 或公开日志。

## 安装

```bash
npm install @aqua-ai/sdk
```

## Service key：业务后端代调用

```ts
import { AquaAIClient } from "@aqua-ai/sdk";

const aqua = new AquaAIClient({
  baseUrl: process.env.AQUA_AI_BASE_URL!,
  auth: { type: "serviceKey", serviceKey: process.env.AQUA_AI_SERVICE_KEY! },
});

const stream = aqua.chat.stream({ userId: "external-user-42", message: "生成今日建议" });
for await (const event of stream) {
  if (event.type === "token") process.stdout.write(event.content);
}

const workflow = await aqua.workflows.run("daily-insight", {
  idempotencyKey: "daily-user-42-2026-08-12",
  runReference: "order-20260812-42",
  input: { userId: "external-user-42", date: "2026-08-12" },
});
```

Service-key 客户端还可调用 `billing.getSummary`、`listUserTransactions`、`topUp`、`deduct`。SDK 原样发送业务侧 user ID，由 Aqua AI 服务端添加/校验租户命名空间。

工作流 ID 是 `workflows.run()` 的调用参数，同一个客户端可调用多个已授权工作流。通常无需传 `workflowVersion`，服务端会使用该工作流的当前激活版本；只有需要复现固定版本时才在单次请求中传入。

## Bearer：用户身份调用

```ts
const userAqua = new AquaAIClient({
  baseUrl: process.env.AQUA_AI_BASE_URL!,
  auth: { type: "bearer", tokenProvider: async () => obtainCurrentUserJwt() },
});

const balance = await userAqua.billing.getBalance();
const history = await userAqua.conversations.history("tenant-id:user-42", "conversation-id", "agent-id");
```

SDK 不接受 `jwt_secret`，也不替业务系统签发用户 JWT。租户 `jwt_secret` 只应由业务方认证服务在服务端安全保存并用于签发终端用户 JWT，签发后的 token 再传给 SDK；仅使用 service-key client 时无需配置它。token provider 会在每个请求前执行，刷新策略由接入方控制。

## 能力与鉴权矩阵

| 领域 | 方法 | Service key | Bearer |
|---|---|---:|---:|
| Chat | `stream`, `complete` | 是，必须传 `userId` | 是 |
| Stateless workflow | `run` | 是 | 否 |
| Conversation | `list`, `history`, `delete` | 否 | 是 |
| Own billing | `getBalance`, `listOwnTransactions` | 否 | 是 |
| Service billing | `getSummary`, `listUserTransactions`, `topUp`, `deduct` | 是 | 否 |

鉴权模式不匹配时，SDK 会在发出网络请求前抛出 `AquaAIAuthModeError`。

## 错误、超时与取消

```ts
import { AquaAIError, AquaAIHttpError } from "@aqua-ai/sdk";

const controller = new AbortController();
try {
  await aqua.chat.complete({ userId: "u-1", message: "hello" }, { signal: controller.signal, timeoutMs: 90_000 });
} catch (error) {
  if (error instanceof AquaAIHttpError) console.error(error.status, error.code, error.requestId, error.retryable);
  else if (error instanceof AquaAIError) console.error(error.kind, error.requestId);
}
```

默认请求超时为 300 秒，调用方仍可通过客户端或单次请求的 `timeoutMs` 覆盖。默认不重试。配置重试后也只对幂等 GET 和带 `idempotencyKey` 的充值开放；聊天、工作流、扣减不会自动重放。

## NestJS

```ts
import { Module } from "@nestjs/common";
import { AquaAIModule } from "@aqua-ai/sdk/nestjs";

@Module({
  imports: [AquaAIModule.forRootAsync({
    inject: [ConfigService],
    useFactory: (config: ConfigService) => ({
      baseUrl: config.getOrThrow("AQUA_AI_BASE_URL"),
      auth: { type: "serviceKey", serviceKey: config.getOrThrow("AQUA_AI_SERVICE_KEY") },
    }),
  })],
})
export class AppModule {}
```

使用 `@Inject(AQUA_AI_CLIENT)` 注入单例客户端。完整示例见 `examples/nestjs/`。

## 密钥轮换

service key 轮换后旧 key 立即失效。更新 Secret Manager/环境变量后重启或滚动发布业务服务；不要在错误日志中打印 options、headers 或环境变量。动态 Bearer token 无需重建客户端。

## 验证

```bash
npm run verify
```

测试服 smoke 默认关闭；仅在使用专用低额度租户时设置 `AQUA_SDK_SMOKE=1`、`AQUA_AI_BASE_URL`、`AQUA_AI_SERVICE_KEY` 及可选 workflow/chat 环境变量。
